package scenariotests;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

@SuppressWarnings("javadoc")
public class IdentityDiskTest {
	
	@Before
	public void setUp() throws Exception {}
	
	@Test
	public void test() {
		fail("Not yet implemented");
	}
	
}