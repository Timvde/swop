package item.identitydisk;

import org.junit.Before;

@SuppressWarnings("javadoc")
public class ChargedIdentityDiskTest {
	
	@Before
	public void setUp() throws Exception {
		
		// Not much to do here it seems. Let's put some other stuff here then.
		//
		// An int, a char and a string walk into a bar and order some drinks. A
		// short while later, the int and char start hitting on the waitress who
		// gets very uncomfortable and walks away. The string walks up to the
		// waitress and says "You'll have to forgive them, they're primitive
		// types."
		
	}
	
}
